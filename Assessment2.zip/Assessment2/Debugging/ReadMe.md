# Debugging and Writing JavaScript

There are a set of tasks to do in  scripts/main.js. Execute them to the best of your ability.  All directions can be found in that file.




## Tips & Hints
- Test selectors
- Work from top to bottom
- Check for spelling mistakes
- Read the comments to see what it should be doing.