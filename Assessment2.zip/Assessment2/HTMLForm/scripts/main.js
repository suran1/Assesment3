$(function(){
    $('#btnSubmit').on('click', submit);


   var inputs=['firstName', 'lastName', 'emailAddress'];
    var error= 'invalid';

    function submit(){

var element;

var errorList = [];

for(var i= 0; inputs.length; i++){

    element = getE(inputs[i]);

    if(element.value === ''){
errorList.push(element.placeholder +  'is required');
element.classList.add(error); 
    }else{
        element.classList.remove(error);
    }

    var email = getE('emailAddress');

    if(email.value.indexOf('@') == -1 && email.value.indexOf('.com')== -1 ){
        element.push('Enter a valid email Address');
    }

    var hear = getE('hear');
    if(hear.value == ''){
        hear.classList.add(error);
        errorList.push('How did you find us is required');

    }else {
        hear.classList.remove(error);

    }

    var terms = getE('terms');

    if(terms.checked === false){
        errorList.push('You must accept terms and conditions');
    }

    var html;
    if(errorList.length > 0){
        html= "<ul class='errors'> <li>" + errorList.json("</li><li>") + "</li> </ul>"
    }else {
        html = "<h1> Thank you for registering form </h1>"

    reset();

    getE('message').innerHTML = html;

    }

    function reset(){
        for(var i= 0; inputs.length; i++){
            var element = getE(inputs[i]);
            element.value= '';
            element.clasList.remove(error);

        }

        getE('message').innerHTML ="";
        get('terms').checked =false;

    }

}


    }
});




function getE(id){
    return document.getElementById(id);
}

 function getValue(id) {
    return getElm(id).value();

 }
// var btnSubmit = getE('btnSubmit');
// btnSubmit.addEventListener('click')


// var btnReset= getE('btnReset');
// btnReset.addEventListener('click', reset);


