# Assessment 2
Complete the work in the Debugging and HTMLForm folders. You'll find ReadMe files in each folder.  Submit your assessment via GitHub or Slack private message.

Use whatever resources available to you except your neighbor or your neighbor's work.



## Point Break Down

### HTMLForm
- Valid HTML & CSS - 20
- JavaScript Validation - 50
- Cleanliness of Code/Comments - 10
- Total - 80
- Challenge available points - 10


### Fixing My Code
- Part 1 fixing broken code - 30
- Part 2 writing utility functions - 40 (10pts each)
- Cleanliness of Code/Comments - 10 
- Total - 80
- Challenge available points - 10

### Speed Vs Accuracy
Going to do something a little different here. Submitting via GitHub between these windows will give you additional points.

- 10:00 - 11:00 - 10 points
- 11:01 - 12:00 - 5 points
- 12:01 - 1:00 - 0 points